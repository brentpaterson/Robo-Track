package com.brentPaterson.roboTrack.GameObjects.Strategies;

public interface IStrategy {
	public void apply();
}
