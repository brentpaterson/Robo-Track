package com.brentPaterson.roboTrack.Collection;

public interface ICollection {
	public void add(Object newObject);
	public IIterator getIterator();
}
