package com.brentPaterson.roboTrack.GameObjects;

public abstract class Fixed extends GameObject {
	
}
