package com.brentPaterson.roboTrack.GameObjects;

public interface ISteerable {
	void changeDirection(int amount);
}
